import React from 'react';
import {useState} from 'react';

const App = () => {

    const [questions, setquestions] = useState([]);

    const addQuestion = () => {
        const newQuestion = {
            id: questions.length + 1,
            question: '',
            answers: [],
        };
        setquestions([...questions, newQuestion]);
    }

    const addAnswer = (questionId) => {
        const newAnswer = {
            id: Date.now(),
            qid: questionId,
            answer: '',
        };
        const newQuestions = questions.map((question) => {
            if (question.id === questionId) {
                question.answers?.push(newAnswer);
            }
            return question;
        });
        setquestions(newQuestions);
    }

    const deleteAnswer = (questionId, answerId) => {
        const newQuestions = questions.map((question) => {
            if (question.id === questionId) {
                question.answers = question.answers.filter((answer) => answer.id !== answerId);
            }
            return question;
        });
        setquestions(newQuestions);
    }

    const deleteQuestion = (questionId) => {
        const newQuestions = questions.filter((question) => question.id !== questionId);
        setquestions(newQuestions);
    }

    return (
        <div>
            <h1>Anket Oluştur</h1>
            <button id="btn-question-ekle" onClick={() => {
                addQuestion();
            }}>
                question Ekle
            </button>
            <div>
                {questions?.map((question) => (
                    <div key={question.id}>
                        <label htmlFor="question">question</label>
                        <input
                            type="text"
                            id="question-{question.id}"
                            name="question"
                        />
                        {/* üsütnde cevap ekle yazan ve her bastığımda bir input oluşturan buton*/}
                        <button id="btn-cevap-ekle" onClick={() => {
                            addAnswer(question.id);
                            console.log(questions)
                        }
                        }>
                            Cevap Ekle
                        </button>
                        {/* cevapları gösteren inputlar */}
                        {question.answers?.map((answer) => (
                            <div key={answer.id}>
                                <div>
                                    <label htmlFor="answer">answer</label>
                                    <input
                                        type="text"
                                        id="answer-{answer.id}"
                                        name="answer"
                                    />
                                    <button id="btn-cevap-sil" onClick={() => {
                                        deleteAnswer(question.id, answer.id);
                                    }}>
                                        Sil
                                    </button>
                                </div>

                            </div>

                        ))}

                    </div>
                ))}
            </div>
        </div>
    );
};

export default App;
